package Characters;
import Utilities.*;
public class Wizard extends Character implements Weapon, Armor{
    protected int currentMagic;
    final protected int maxMagic;
    public Wizard(String n, int s, int d, int i, int m){
        super(n, s, d, i);
        maxMagic = m;
        currentMagic = maxMagic;
    }
    @Override
    public int attack(){
        damage = dice.roll()+strength;
        wound();
        return damage;
    }
    @Override
    public int useWeapon(){
        damage = dice.roll()+(strength*2);
        wound();
        return damage;
    }
    @Override
    public int useArmor(){
        return heal(strength);
    }
    public int castLightningBolt(){
        if(currentMagic > 5){
            currentMagic -= 5;
            damage = dice.roll() + intelligence;
            wound();
            return damage;
        }
        else{
            return 0;
        }
    }
    
    public int castHeal(){
        
        if(currentMagic > 8){
            currentMagic -= 8;
            return heal(intelligence);
        }
        else{
            return 0;
        }
    }
    public int getCurrentMagic(){
        return currentMagic;
    }
    public int getMaxMagic(){
        return maxMagic;
    }
}