package Characters;
import Utilities.*;
public class OldBeggar extends Character implements Weapon, Armor{
    protected int currentAge;
    final protected int maxAge;
    public OldBeggar(String n, int s, int d, int i, int a){
        super(n, s, d, i);
        maxAge = a;
        currentAge = maxAge;
    }
    @Override
    public int attack(){
        damage = dice.roll()+strength;
        wound();
        return damage;
    }
    
    @Override
    public int useWeapon(){
        damage = dice.roll()+(strength*2);
        wound();
        return damage;
    }
    @Override
    public int useArmor(){
        return heal(strength);
    }
    public int grip(){
        if(currentAge > 5){
            currentAge -= 5;
            damage = dice.roll() + dexterity;
            wound();
            return damage;
        }
        else{
            return 0;
        }
    }
    public int getCurrentAge(){
        return currentAge;
    }
    public int getMaxAge(){
        return maxAge;
    }
}