package Utilities;

public interface Weapon {
    int useWeapon();
}