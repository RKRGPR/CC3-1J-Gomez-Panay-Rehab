package Utilities;

public interface Armor {
    int useArmor();
}
