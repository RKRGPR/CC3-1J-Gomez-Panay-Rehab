package item;
/**
 * interface Armor declaration
 * @author December Avis Gomez
 */
public interface Armor {
    /**
     * Abstract useArmor() declaration
     * @return the lifeUp
     */
    int useArmor();
}
