package item;
/**
 * interface Weapon declaration
 * @author December Avis Gomez
 */
public interface Weapon {
    /**
     * Abstract useWeapon() declaration
     * @return the lifeUp
     */
    int useWeapon();
}