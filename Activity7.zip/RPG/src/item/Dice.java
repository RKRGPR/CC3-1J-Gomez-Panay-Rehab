package item;
/**
 * import Random Class from java.util package
 */
import java.util.Random;
/**
 * Dice class generates a random number from 1-6
 * @author December Avis Gomez
 */
public class Dice{
    /**
     * Object r from Random class declaration
     */
    private Random r = new Random();
    /**
     * roll()
     * @return a random integer from 1-6
     */
    public int roll(){
        return (int) r.nextInt(6)+1;
    }
}