package test;
import character.*;
public class TestCharacter{
    public static void main(String [] args){
        Wizard bob = new Wizard("Jerry", 5, 8, 10, 50);
        OldBeggar joe = new OldBeggar("Manang", 8, 10, 5, 50);
        int i = 1;
        while((bob.getCurrentLife()>0) && (joe.getCurrentLife()>0)){
            System.out.println("Round "+i); i++;
            System.out.println(bob.getName()+":\nLife: "+bob.getCurrentLife());
            System.out.println(joe.getName()+":\nLife: "+joe.getCurrentLife());
            System.out.println(bob.getName()+" attacks " + joe.getName() + " for " + joe.attack());
            System.out.println(joe.getName()+" attacks " + bob.getName() + " for " + bob.attack());
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()>0)) {
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(joe.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()>0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(bob.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println("Draw!");
                break;
            }
        }
    }
}