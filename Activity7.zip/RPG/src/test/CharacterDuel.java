package test;
import character.OldBeggar;
import character.Wizard;
import java.util.Scanner;
public class CharacterDuel{
    static Wizard bob = new Wizard("STRANGE", 5, 8, 10, 50);
    static OldBeggar joe = new OldBeggar("NINEGAR", 8, 10, 5, 50);
    static Scanner s = new Scanner(System.in);
    static char attackType;
    static String cont;
    public static void main(String [] args){
        int i = 1;
        while((bob.getCurrentLife()>0) && (joe.getCurrentLife()>0)){
            if(i == 1){
                System.out.println("======================== ROUND "+i+" ========================"); i++;
            }
            else{
                System.out.println("\n\n======================== ROUND "+i+" ========================"); i++;
            }
            System.out.println("------------------------ "+bob.getName()+" ------------------------\nHealth: "+bob.getCurrentLife()+"/"+bob.getMaxlife()+"\t\tMana: "+bob.getCurrentMagic()+"/"+bob.getMaxMagic());
            System.out.println("------------------------ "+joe.getName()+" ------------------------\nHealth: "+joe.getCurrentLife()+"/"+joe.getMaxlife()+"\t\tMana: "+joe.getCurrentAge()+"/"+joe.getMaxAge());
            attackTypeBob();
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()>0)) {
                System.out.println(bob.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(joe.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()>0)&&(joe.getCurrentLife()<=0)){
                System.out.println(joe.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(bob.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+" is down!");
                System.out.println(joe.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println("Draw!");
                break;
            }
            attackTypeJoe();
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()>0)) {
                System.out.println(bob.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(joe.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()>0)&&(joe.getCurrentLife()<=0)){
                System.out.println(joe.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(bob.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+" is down!");
                System.out.println(joe.getName()+" is down!");
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println("Draw!");
                break;
            }
        }
    }
    static void attackTypeBob(){
        System.out.println(bob.getName()+": MOVES");
        System.out.println("[Q] Lightning Bolt\t[W] Normal Attack\t[E] Heal\n[R] Use Weapon\t\t[T] Use Armor");
        System.out.print("CHOOSE ATTACK: ");
        attackType = s.next().charAt(0);
        switch (attackType) {
            case 'q':
            case 'Q':
                System.out.println(bob.getName()+" attacks "+joe.getName()+" for "+joe.grip());
                break;
            case 'w':
            case 'W':
                System.out.println(bob.getName()+" attacks "+joe.getName()+" for "+joe.attack());
                break;
            case 'e':
            case 'E':
                System.out.println(bob.getName()+" heals by "+bob.castHeal());
                break;
            case 'r':
            case 'R':
                System.out.println(bob.getName()+" used a weapon and attacks "+joe.getName()+" for "+joe.useWeapon());
                break;
            case 't':
            case 'T':
                System.out.println(bob.getName()+" used armor and heals by "+bob.useArmor());
                break;
            default:
                System.out.println("Attack type not recognized!");
                attackTypeBob();
        }
    }
    static void attackTypeJoe(){
        System.out.println(joe.getName()+": MOVES");
        System.out.println("[Q] Grip\t\t[W] Normal Attack\n[R] Use Weapon\t\t[T] Use Armor");
        System.out.print("CHOOSE ATTACK: ");
        attackType = s.next().charAt(0);
        switch (attackType) {
            case 'q':
            case 'Q':
                System.out.println(joe.getName()+" attacks "+bob.getName()+" for "+bob.castLightningBolt());
                break;
            case 'w':
            case 'W':
                System.out.println(joe.getName()+" attacks "+bob.getName()+" for "+bob.attack());
                break;
            case 'r':
            case 'R':
                System.out.println(joe.getName()+" used a weapon and attacks "+bob.getName()+" for "+bob.useWeapon());
                break;
            case 't':
            case 'T':
                System.out.println(joe.getName()+" used armor and heals by "+joe.useArmor());
                break;
            default:
                System.out.println("Attack type not recognized!");
                attackTypeJoe();
        }
    }
}