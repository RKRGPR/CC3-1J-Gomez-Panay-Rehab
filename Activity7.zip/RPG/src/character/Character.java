package character;
/**
 * import Dice class from the item package
 */
import item.Dice;
/**
 * Character is the parent/Super Class
 * Abstract Class
 * @author Rehab, Panay, Gomez
 */
public abstract class Character{
    /**
     * String attribute name added
     * declared with protected as access modifier
     */
    protected String name;
    /**
     * integer attributes strength, dexterity, intelligence, currentLife, damage, lifeUp added
     * declared with protected as access modifier
     */
    protected int strength, dexterity, intelligence, currentLife, damage, lifeUp;
    /**
     * integer attribute maxLife added
     * declared with final value and protected as access modifier
     */
    final protected int maxLife;
    Dice dice = new Dice();
    /**
     * Default constructor
     */
    public Character(){
        name = "";
        strength = 0;
        dexterity = 0;
        intelligence = 0;
        maxLife = dice.roll()*10;
        currentLife = maxLife;
    }
    /**
     * Overloaded constructor
     * @param n
     * @param s
     * @param d
     * @param i 
     */
    public Character(String n, int s, int d, int i){
        name = n;
        strength = s;
        dexterity = d;
        intelligence = i;
        maxLife = dice.roll()*10;
        currentLife = maxLife;
    }
    /**
     * Abstract attack() declaration
     * @return the damage
     */
    public abstract int attack();
    public void wound(){
        if(currentLife-damage < 0){
            currentLife -= currentLife;
        }else{
            currentLife -= damage;
        }
    }
    /**
     * heal()
     * @return the lifeUp
     */
    public int heal(){
        lifeUp = dice.roll();
        if(currentLife+lifeUp > maxLife){
            lifeUp = maxLife - currentLife;
            currentLife += lifeUp;
            return lifeUp;
        }
        else{
        currentLife += lifeUp;
        return lifeUp;
        }
    }
    /**
     * overloaded heal()
     * @param h
     * @return 
     */
    public int heal(int h){
        lifeUp = dice.roll() + h;
        if(currentLife+lifeUp > maxLife){
            lifeUp = maxLife - currentLife;
            currentLife += lifeUp;
            return lifeUp;
        }
        else{
        currentLife += lifeUp;
        return lifeUp;
        }
    }
    /**
     * @return the name
     */
    public String getName(){
        return name;
    }
    /**
     * @return the strength
     */
    public int getStrength(){
        return strength;
    }
    /**
     * @return the dexterity
     */
    public int getDexterity(){
        return dexterity;
    }
    /**
     * @return the intelligence
     */
    public int getIntelligence(){
        return intelligence;
    }
    /**
     * @return the currentLife
     */
    public int getCurrentLife(){
        return currentLife;
    }
    /**
     * @return the maxLife
     */
    public int getMaxlife(){
        return maxLife;
    }
}