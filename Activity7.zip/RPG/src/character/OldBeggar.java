package character;
/**
 * import the Armor and Weapon interfaces from item package
 */
import item.Armor;
import item.Weapon;
/**
 * OldBeggar is a child/sub class of Character class
 * @author December Avis Gomez
 */
public class OldBeggar extends Character implements Weapon, Armor{
    /**
     * integer attribute currentAge added
     * declared with protected as access modifier
     */
    protected int currentAge;
    /**
     * integer attribute maxAge added
     * declared with final value and protected as access modifier
     */
    final protected int maxAge;
    /**
     * Overloaded constructor
     * @param n
     * @param s
     * @param d
     * @param i
     * @param a 
     */
    public OldBeggar(String n, int s, int d, int i, int a){
        super(n, s, d, i);
        maxAge = a;
        currentAge = maxAge;
    }
    /**
     * Override attack()
     * @return the damage
     */
    @Override
    public int attack(){
        damage = dice.roll()+strength;
        wound();
        return damage;
    }
    /**
     * Overrides useWeapon()
     * @return the damage
     */
    @Override
    public int useWeapon(){
        damage = dice.roll()+(strength*2);
        wound();
        return damage;
    }
    /**
     * Overrides useArmor()
     * @return the lifeUp
     */
    @Override
    public int useArmor(){
        return heal(strength);
    }
    /**
     * "Special attack" = grip()
     * @return the damage
     */
    public int grip(){
        if(currentAge > 5){
            currentAge -= 5;
            damage = dice.roll() + dexterity;
            wound();
            return damage;
        }
        else{
            return 0;
        }
    }
    /**
     * @return the currentAge
     */
    public int getCurrentAge(){
        return currentAge;
    }
    /**
     * @return the maxAge
     */
    public int getMaxAge(){
        return maxAge;
    }
}