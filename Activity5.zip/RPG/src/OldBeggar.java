public class OldBeggar extends Character{
    protected int currentAge;
    final protected int maxAge;
    public OldBeggar(String n, int s, int d, int i, int a){
        super(n, s, d, i);
        maxAge = a;
        currentAge = maxAge;
    }
    public int grip(){
        if(currentAge > 5){
            currentAge -= 5;
            damage = dice.roll() + dexterity;
            wound();
            heal();
            return damage;
        }
        else{
            return 0;
        }
    }
    public int getCurrentAge(){
        return currentAge;
    }    
}