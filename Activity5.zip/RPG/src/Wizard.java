public class Wizard extends Character{
    protected int currentMagic;
    final protected int maxMagic;
    public Wizard(String n, int s, int d, int i, int m){
        super(n, s, d, i);
        maxMagic = m;
        currentMagic = maxMagic;
    }
    public int castLightningBolt(){
        if(currentMagic > 5){
            currentMagic -= 5;
            damage = dice.roll() + intelligence;
            wound();
            heal();
            return damage;
        }
        else{
            return 0;
        }
    }
    public int castHeal(){
        if(currentMagic > 8){
            currentMagic -= 8;
            return heal() + intelligence;
        }
        else{
            return 0;
        }
    }
    public int getCurrentMagic(){
        return currentMagic;
    }
}