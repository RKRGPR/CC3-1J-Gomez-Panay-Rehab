import java.util.Scanner;
public class CharacterDuel{
    static Wizard bob = new Wizard("Jerry", 5, 8, 10, 50);
    static OldBeggar joe = new OldBeggar("Manang", 8, 10, 5, 50);
    static Scanner s = new Scanner(System.in);
    static char bobAttack, joeAttack;
    public static void main(String [] args){
        int i = 1;
        while((bob.getCurrentLife()>0) && (joe.getCurrentLife()>0)){
            System.out.println("Round "+i); i++;
            System.out.println(bob.getName()+":\nLife: "+bob.getCurrentLife()+"\nMagic: "+bob.getCurrentMagic());
            System.out.println(joe.getName()+":\nLife: "+joe.getCurrentLife()+"\nAge: "+joe.getCurrentAge());
            attackTypeBob();
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()>0)) {
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(joe.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()>0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(bob.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println("Draw!");
                break;
            }
            attackTypeJoe();
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()>0)) {
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(joe.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()>0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println(bob.getName()+" wins!");
                break;
            }
            if((bob.getCurrentLife()<=0)&&(joe.getCurrentLife()<=0)){
                System.out.println(bob.getName()+"'s Final Health: "+bob.getCurrentLife());
                System.out.println(joe.getName()+"'s Final Health: "+joe.getCurrentLife());
                System.out.println("Draw!");
                break;
            }
        }
    }
    static void attackTypeBob(){
        System.out.println("Choose attack type for "+bob.getName()+": ");
        System.out.println("[x] Lightning Bolt | [o] Normal Attack | [s] Heal");
        bobAttack = s.next().charAt(0);
        switch (bobAttack) {
            case 'x':
            case 'X':
                System.out.println(bob.getName()+" attacks "+joe.getName()+" for "+joe.grip());
                break;
            case 'o':
            case 'O':
                System.out.println(bob.getName()+" attacks "+joe.getName()+" for "+joe.attack());
                break;
            case 's':
            case 'S':
                System.out.println(bob.getName()+" heals by "+bob.castHeal());
                break;
            default:
                System.out.println("Attack type not recognized!");
                attackTypeBob();
        }
    }
    static void attackTypeJoe(){
        System.out.println("Choose attack type for "+joe.getName()+": ");
        System.out.println("[x] Grip | [o] Normal Attack");
        bobAttack = s.next().charAt(0);
        switch (bobAttack) {
            case 'x':
            case 'X':
                System.out.println(joe.getName()+" attacks "+bob.getName()+" for "+bob.castLightningBolt());
                break;
            case 'o':
            case 'O':
                System.out.println(joe.getName()+" attacks "+bob.getName()+" for "+bob.attack());
                break;
            default:
                System.out.println("Attack type not recognized!");
                attackTypeBob();
        }
    }
}