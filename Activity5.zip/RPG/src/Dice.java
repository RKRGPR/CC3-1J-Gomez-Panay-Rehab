import java.util.Random;
public class Dice{
    private Random r = new Random();
    public int roll(){
        return (int) r.nextInt(6)+1;
    }
}